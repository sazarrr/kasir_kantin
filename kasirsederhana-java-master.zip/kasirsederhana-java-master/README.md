# kasirsederhana-java
Tugas besar kelompok mata kuliah OOP semester 3 ARS University dengan kelompok:

* 17200014 - Wira Sanjaya
* 17201003 - Imam Muhammad Mannar Shahih
* 17201018 - Elin Sopiah
